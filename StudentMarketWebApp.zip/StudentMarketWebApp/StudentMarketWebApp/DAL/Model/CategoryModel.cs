﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace BitsSoftware
{
    public class CategoryModel
    {
        public int CategoryId { get; set; }
        public string CategoryName { get; set; }
        public string InTime { get; set; }

    }
}